<?php
session_start();
define('ROOT_URL', 'http://localhost/blog/');
define('DB_HOST', 'localhost');
define('DB_USER', 'prudhvi');
define('DB_PASS', 'admin1234');
define('DB_NAME', 'blog');
