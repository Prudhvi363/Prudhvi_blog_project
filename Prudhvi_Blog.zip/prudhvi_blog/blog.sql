-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2025 at 03:26 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `description`) VALUES
(2, 'Wild Life', 'This is the description for wild life category'),
(4, 'Science &amp; Technology', 'This is the description or science and technology'),
(5, 'Uncategorized', 'This is the description for uncategorized category'),
(7, 'Art', 'This is the description for the art category'),
(8, 'Food', 'This is the description food category'),
(9, 'Travel', 'This is the description for travel category\r\n'),
(10, 'Animals', 'Description for animals category');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `category_id` int(11) UNSIGNED DEFAULT NULL,
  `author_id` int(11) UNSIGNED NOT NULL,
  `is_featured` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `thumbnail`, `date_time`, `category_id`, `author_id`, `is_featured`) VALUES
(14, 'Beyond the Frost: Life at The Wall', 'Entry 3 &mdash; A Cold Brotherhood\r\nCastle Black, The Wall\r\nYear 298 AC, Month 5, Day 12\r\n\r\nThe cold is not the worst part.\r\nYou&#039;d think it would be &mdash; the wind that howls like a ghost through every crack in Castle Black, the snow that settles in your bones and stays there. But no. It&rsquo;s the silence that gets to you. The silence after the training ends, when the fires dim, and you start to remember the world you left behind.\r\n\r\nToday I climbed the Wall.\r\n\r\nThey say it&#039;s 700 feet of ice, but it might as well be the edge of the world. The wind up there makes it hard to breathe. You can see everything &mdash; the vast white nothingness of the Haunted Forest, the glint of frozen rivers far off, and sometimes, if you&#039;re lucky (or unlucky), the vague shapes that move beyond the trees.\r\n\r\nGhost came with me.\r\nHe&rsquo;s taken to watching the forest like he senses something I don&rsquo;t. Maybe he&rsquo;s right. There&rsquo;s talk in the halls &mdash; whispers of wildlings moving, of shadows with blue eyes.\r\n\r\nMeals are mostly stew. Or things pretending to be stew.\r\nWe eat in silence, shoulder to shoulder, a brotherhood born of vow, not choice. Some of the new recruits are boys like me, second sons and bastards. Others are thieves, rapists, or worse. But here, we&rsquo;re all the same: black cloaks against the snow, sworn to guard a realm that barely remembers we exist.\r\n\r\nI miss Winterfell.\r\nThe sound of Arya&rsquo;s laughter, the warmth of the hounds by the hearth, even Robb&rsquo;s smug grin when he bested me in sparring. I miss being someone&#039;s son, not just another sword in the dark.\r\n\r\nBut I made my choice.\r\nI said the words. I am the sword in the darkness. The watcher on the walls. The shield that guards the realms of men.\r\n\r\nAnd though I dream of summer fields and warm bread, I know the Wall is where I&rsquo;m meant to be.\r\n\r\nBecause something is coming.\r\nAnd we must be ready.\r\n\r\n&mdash; Jon', '1753483895Castle-Black.png', '2025-07-25 22:51:35', 9, 12, 1),
(15, 'Ash and Flame: My Journey to Dragonstone&quot; &mdash; by Jon Snow', 'Entry 14 &mdash; The Queen and Her Dragons\r\nDragonstone\r\nYear 304 AC, Month 7, Day 2\r\n\r\nThe sea hates the North.\r\nThat much I&rsquo;ve learned.\r\n\r\nIt tossed our ship like a direwolf playing with a bone. Saltwater stung our faces and soaked through every layer. Davos said it was a calm voyage by his standards. I don&rsquo;t know how he does it &mdash; the man could sail through a storm with a smile and a joke. I had neither.\r\n\r\nBut as we approached Dragonstone, everything changed.\r\n\r\nA mountain of black rock rising from the sea, jagged and ancient &mdash; like it had clawed its way out of the earth long before men ever stood upon Westeros. The castle itself is a thing of legend. Carved by Valyrian hands. Towers shaped like dragons. Fire made stone.\r\n\r\nIt is not welcoming.\r\nIt is powerful.\r\nAnd it knows it.\r\n\r\nI met her today. Daenerys Stormborn.\r\nShe sits on a throne of black stone, flame behind her eyes, titles trailing behind her like a cloak.\r\n\r\nBreaker of Chains. Mother of Dragons.\r\n\r\nShe demanded I bend the knee.\r\nI told her I would not.\r\n\r\nWe need each other &mdash; that much is clear. But I will not kneel to a queen I do not know, not when the dead march in the North. Not when I&rsquo;ve seen them myself.\r\n\r\nThe dragons are real.\r\nI saw them. I felt them.\r\n\r\nThey are not just beasts. They are heat and fury and history in the sky. When Drogon flew overhead, the men ducked. Ghost howled. I didn&rsquo;t move &mdash; not out of courage, but out of awe. For a moment, I understood what Aegon must have looked like to the kings he conquered.\r\n\r\nTyrion believes me.\r\nHe remembered what I said years ago at the Wall &mdash; about wearing black and being a bastard. He&rsquo;s clever. He sees more than most, and I hope that means he sees the truth of what&rsquo;s coming.\r\n\r\nDragonstone smells of sulfur and secrets.\r\nBeneath it are mines full of dragonglass &mdash; the very weapon we need to fight the army of the dead. She has agreed to let us mine it.\r\n\r\nIt&rsquo;s a start.\r\n\r\nI do not know if she&rsquo;ll be a queen for Westeros.\r\nBut I know this much:\r\n\r\nIf the living are to survive,\r\nthe fire and the ice must stand together.\r\n\r\n&mdash; Jon\r\n\r\n', '1753484106dragonstone.jpg', '2025-07-25 22:55:06', 9, 12, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `is_admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `email`, `password`, `avatar`, `is_admin`) VALUES
(12, 'john ', 'snow', 'john', 'johnsnow@gmail.com', '$2y$10$dzWtsD34I25i7uTEQyVuPu.sV44gvk57zc5suMDZbL4JMWIHqZFpy', '1753483178johnsnow.jpg', 1),
(13, 'ned', 'stark', 'Ned', 'nedstark@gmail.com', '$2y$10$5GEiJrt9rWLZFo9.7pV.nepkpryNkFTHF8EomhChJ01ov62l.acS.', '1753483238eddedstark.jpg', 1),
(14, 'arya', 'stark', 'arya', 'aryastark@yahoo.com', '$2y$10$uGdUqlebpPDhSsSR7sDmueJwK5M2mT.EQz14bB.kOoKQbDsOjj6r6', '1753483280aryastark.jpg', 0),
(15, 'Tyrion', 'Lannister', 'tyrion', 'tyrionlannister@hotmail.com', '$2y$10$5nIhMK8JiBgGJ0KVurBvKug180lyIwimnEXlQ9sG77pN.N7NU3tJu', '1753483409tyrion lannister.jpg', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_blog_category` (`category_id`),
  ADD KEY `FK_blog_author` (`author_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `FK_blog_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_blog_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
